# Blog-post-Pro

- Always keep `dev` updated (`git pull origin dev` while you are on branch `dev`)
- **NEVER** push to `dev` branch. 
- while making new branches, use command: `git checkout -b your-name/feature||bug||refactor/some-name-for-current-work`
